import express from 'express';

const app = express();
const PORT = process.env.PORT || 3000;

// 기본 라우트
app.get('/', (req, res) => {
    res.send('Hello, World!');
});

app.get('/api/status',(req,res)=>{
    res.status(200).json({status:'hello!', timestamp: Date.now()});
});

app.get('/hello',(req,res)=>{
    res.json({str: "안녕하세요, Express!"});
})

function formatDate(time){
    const date = new Date(time);
    const pad = (n) => n.toString().padStart(2, '0');

    const year = date.getFullYear();
    const month = pad(date.getMonth() + 1);
    const day = pad(date.getDate());
    const hours = pad(date.getHours());
    const minutes = pad(date.getMinutes());
    const seconds = pad(date.getSeconds());

    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}

app.get('/api/time',(req,res)=>{
    const time = Date.now();
    const format = formatDate(time);
    res.json({time: format});
})

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
